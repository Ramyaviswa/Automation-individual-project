package Mainfunctionalities;

import org.testng.annotations.Test;

import pom_PageObjectModel.Open_Mrs;

import org.testng.annotations.BeforeTest;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.testng.annotations.AfterTest;

public class ActiveVisits 
{
	WebDriver driver;
	@BeforeTest
	public void beforeTest() throws Exception
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\HP\\Desktop\\Automation Testing\\BrowserExtension\\edgedriver.exe");
		driver=new EdgeDriver();
		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();

	}
	@Test(priority=1)
	public void activeVisits() throws Exception
	{
		Open_Mrs o=new Open_Mrs();
		o.maximizeBrowser(driver);
		Thread.sleep(2000);
		o.getUrl(driver);
		Thread.sleep(2000);
		o.enterUsername(driver,"Admin");
		Thread.sleep(2000);
		o.enterPassword(driver,"Admin123");
		Thread.sleep(2000);
		o.clickOnLocation(driver);
		Thread.sleep(2000);
		o.clickOnLogin(driver);
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[@id=\"org-openmrs-module-coreapps-activeVisitsHomepageLink-org-openmrs-module-coreapps-activeVisitsHomepageLink-extension\"]")).click();
		Thread.sleep(2000);
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		Thread.sleep(2000);
		File des=new File("C:\\\\Users\\\\HP\\\\Desktop\\\\Automation Testing\\\\activeVisits.png");
		Thread.sleep(2000);
		FileUtils.copyFile(src,des);
	}
	@Test(priority=2)
	public void captureVitals() throws Exception
	{
		driver.get("https://demo.openmrs.org/openmrs/coreapps/findpatient/findPatient.page?app=referenceapplication.vitals");
		//driver.findElement(By.xpath("/html/body/div/div[3]/div[3]/div/a[3]")).click();
		Thread.sleep(2000);
		TakesScreenshot ts=(TakesScreenshot)driver;
		File src=ts.getScreenshotAs(OutputType.FILE);
		Thread.sleep(2000);
		File des=new File("C:\\Users\\HP\\Desktop\\Automation Testing\\capturevitals.png");
		Thread.sleep(2000);
		FileUtils.copyFile(src,des);
	}
	@AfterTest
	public void afterTest()
	{
		driver.close();
	}

}
