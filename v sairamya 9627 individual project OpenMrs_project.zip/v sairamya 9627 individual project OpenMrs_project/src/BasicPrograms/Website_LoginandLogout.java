package BasicPrograms;

import java.util.Scanner;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Website_LoginandLogout
{

	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\\\Users\\\\HP\\\\Desktop\\\\Automation Testing\\\\Bowser Extension\\\\edgedriver.exe");
		WebDriver driver=new EdgeDriver();

		driver.manage().window().maximize();
		driver.manage().deleteAllCookies();
		
		String username, password;
		Scanner s = new Scanner(System.in);
		 
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
		Thread.sleep(2000);

		//Username
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys("Admin");
		Thread.sleep(2000);

		//password
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys("Admin123");
		Thread.sleep(2000);

		//click on location: Registration Desk
		driver.findElement(By.xpath("//*[@id=\"Registration Desk\"]")).click();
		Thread.sleep(2000);

		//login
		driver.findElement(By.xpath("//*[@id=\"loginButton\"]")).click();
		Thread.sleep(2000);

		//logout
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
		Thread.sleep(2000);

		driver.close();


	}

}
