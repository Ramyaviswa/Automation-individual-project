package BasicPrograms;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Website_URL {

	public static void main(String[] args) throws Exception
	{
		
	   System.setProperty("webdriver.chrome.driver", " C:\\\\Users\\\\HP\\\\Desktop\\\\Automation Testing\\\\Bowser Extension\\\\Edgedriver.exe");
       WebDriver driver=new EdgeDriver();
       driver.manage().window().maximize();
       driver.manage().deleteAllCookies();
       
       driver.get("https://demo.openmrs.org/openmrs/login.htm");
       Thread.sleep(2000);
       driver.close();
	}

}
