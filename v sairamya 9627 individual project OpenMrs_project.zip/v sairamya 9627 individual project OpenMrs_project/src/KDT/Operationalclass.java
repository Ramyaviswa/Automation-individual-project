package KDT;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Operationalclass
{
	WebDriver driver;
	public void maximizeBrowser()
	{
		driver.manage().window().maximize();
	}
	public void getUrl()
	{
		driver.get("https://demo.openmrs.org/openmrs/login.htm");
	}
	public void enterUsername(String usn)
	{
		driver.findElement(By.xpath("//*[@id=\"username\"]")).sendKeys(usn);
	}
	public void enterPassword(String pwd)
	{
		driver.findElement(By.xpath("//*[@id=\"password\"]")).sendKeys(pwd);
	}
	public void clickOnLocation()
	{
		driver.findElement(By.xpath("//*[@id=\"Registration Desk\"]")).click();
	}
	public void clickOnLogin()
	{
		driver.findElement(By.xpath("//*[@id=\"loginButton\"]")).click();
	}
	public void clickOnLogout()
	{
		driver.findElement(By.xpath("//*[@id=\"navbarSupportedContent\"]/ul/li[3]/a")).click();
	}
	public void closeBrowser()
	{
		driver.close();
	}	
}


